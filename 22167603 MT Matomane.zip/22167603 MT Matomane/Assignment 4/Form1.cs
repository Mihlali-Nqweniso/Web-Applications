﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string membershipNum;
            double amountPayable, halfHour, rateAmount, semi_amount, weekRateAmount, withOutRate;

            double weekHigherRate = 0.1;



            membershipNum = txtMemberNumber.Text;

            //WITHOUT WEEKEND
            if (radStudent.Checked)
            {

                label4.Text = ("Booking of facilities for students and staff is free of charge");
            }

            else if (radStaff.Checked)
            {
                label4.Text = ("Booking of facilities for students and staff is free of charge");
            }
            if (radPublic.Checked)
            {

                if (radSwimming.Checked)                             //SWIMMING POOL
                {

                    if (rad30Min.Checked)
                    {
                        halfHour = 11 / 2;

                        //30 minutes
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{halfHour}";
                    }

                    else if (rad1Hour.Checked)
                    {

                        amountPayable = 11.00 * 1; //1hour
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }

                    else if (rad90Min.Checked)
                    {
                        halfHour = 11.00 / 2;
                        amountPayable = 11.00 + halfHour;        //90 minutes
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }

                    else if (rad2Hours.Checked)
                    {
                        halfHour = 11.00 / 2;
                        semi_amount = 11.00 * 2;

                        amountPayable = semi_amount + halfHour;     //2hours
                        label4.Text = $"The amount due for the facilities for member{membershipNum} = R{amountPayable}";
                    }
                }



                if (radWeights.Checked)                               //WEIGHTS
                {
                    if (rad30Min.Checked)
                    {

                        halfHour = 8.00 / 2;  //30 minutes
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{halfHour}";
                    }

                    else if (rad1Hour.Checked)
                    {
                        amountPayable = 8.00 * 1; //1hour
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }

                    else if (rad90Min.Checked)
                    {
                        halfHour = 8.00 / 2;
                        amountPayable = 8.00 + halfHour;     //90 minutes
                        label4.Text = $"The amount due for the facilities for member{membershipNum} = R{amountPayable}";
                    }

                    else if (rad2Hours.Checked)
                    {
                        halfHour = 8.00 / 2;
                        semi_amount = 8.00 * 2;

                        amountPayable = semi_amount + halfHour;   //2hours
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }
                }

                if (radGymnasium.Checked)                           //GYMNASIUM
                {
                    if (rad30Min.Checked)
                    {


                        halfHour = 11.00 / 2;  //30 minutes
                        label4.Text = $"The amount due for the facilities for member{membershipNum} = R{halfHour}";
                    }

                    else if (rad1Hour.Checked)
                    {
                        amountPayable = 11.00 * 1; //1hour
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }

                    else if (rad90Min.Checked)
                    {
                        halfHour = 11.00 / 2;
                        amountPayable = 11.00 + halfHour;      //90 minutes
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }

                    else if (rad2Hours.Checked)
                    {
                        halfHour = 11.00 / 2;
                        semi_amount = 13.00 * 2;

                        amountPayable = semi_amount + halfHour;//2hours
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }
                }


                if (radSquash.Checked)                      //SQUASH COURT
                {
                    if (rad30Min.Checked)
                    {


                        halfHour = 13.00 / 2;  //30 minutes
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{halfHour}";
                    }

                    else if (rad1Hour.Checked)
                    {
                        amountPayable = 13.00 * 1; //1hour
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }

                    else if (rad90Min.Checked)
                    {
                        halfHour = 13.00 / 2;
                        amountPayable = 13.00 + halfHour;


                        //90 minutes
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }

                    else if (rad2Hours.Checked)
                    {

                        halfHour = 13.00 / 2;
                        semi_amount = 13.00 * 2;

                        amountPayable = semi_amount + halfHour;  //2hours
                        label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                    }
                }

            }



            //WITHIN WEEKEND

            if (checkBox1.Checked)
            {

                membershipNum = txtMemberNumber.Text;

                if (radStudent.Checked)
                {

                    label4.Text = ("Booking of facilities for students and staff is free of charge");
                }

                if (radStaff.Checked)
                {
                    label4.Text = ("Booking of facilities for students and staff is free of charge");
                }
                if (radPublic.Checked)
                {

                    if (radSwimming.Checked)                             //SWIMMING POOL
                    {

                        if (rad30Min.Checked)
                        {
                            halfHour = 11.00 * 0.5;
                            rateAmount = weekHigherRate * halfHour;
                            amountPayable = halfHour + rateAmount;
                            //rateAmount = weekHigherRate * 11.00;
                            //   halfHour = 11.00 / 2;
                            //amountPayable = (halfHour + rateAmount);

                            //30 minutes
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad1Hour.Checked)
                        {

                            rateAmount = weekHigherRate * 11.00;
                            amountPayable = (11.00 + rateAmount) * 1; //1hour
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad90Min.Checked)
                        {

                            semi_amount = 11.00 + 5.5;
                            rateAmount = weekHigherRate * semi_amount;

                            amountPayable = (semi_amount + rateAmount);        //90 minutes
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad2Hours.Checked)
                        {
                            halfHour = 11.00 / 2;
                            semi_amount = 11.00 * 2;
                            withOutRate = semi_amount + halfHour;
                            weekRateAmount = weekHigherRate * withOutRate;
                            amountPayable = weekRateAmount + withOutRate;


                            //halfHour = 11.00 / 2;
                            //semi_amount = 11.00 * 2;
                            //weekRateAmount = weekHigherRate * semi_amount;
                            //amountPayable = weekRateAmount + semi_amount + halfHour;
                            //2hours
                            label4.Text = $"The amount due for the facilities for member{membershipNum} = R{amountPayable}";
                        }
                    }



                    if (radWeights.Checked)                               //WEIGHTS
                    {
                        if (rad30Min.Checked)
                        {
                            halfHour = 8.00 * 0.5;
                            rateAmount = weekHigherRate * halfHour;

                            amountPayable = (halfHour + rateAmount);

                            //rateAmount = weekHigherRate * 8.00;
                            //halfHour = 8.00 / 2;
                            //amountPayable = (halfHour + rateAmount);  //30 minutes
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad1Hour.Checked)
                        {
                            rateAmount = weekHigherRate * 8.00;
                            amountPayable = (8.00 + rateAmount) * 1;    //1hour
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad90Min.Checked)
                        {
                            semi_amount = 8.00 * 1.5;
                            rateAmount = weekHigherRate * semi_amount;

                            amountPayable = (semi_amount + rateAmount);


                            //90 minutes
                            label4.Text = $"The amount due for the facilities for member{membershipNum} = R{amountPayable}";
                        }

                        else if (rad2Hours.Checked)
                        {

                            halfHour = 8.00 / 2;
                            semi_amount = 8.00 * 2;
                            withOutRate = semi_amount + halfHour;
                            weekRateAmount = weekHigherRate * withOutRate;
                            amountPayable = weekRateAmount + withOutRate;

                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }
                    }

                    if (radGymnasium.Checked)                           //GYMNASIUM
                    {
                        if (rad30Min.Checked)
                        {

                            halfHour = 11.00 * 0.5;
                            rateAmount = weekHigherRate * halfHour;

                            amountPayable = (halfHour + rateAmount);  //30 minutes
                            label4.Text = $"The amount due for the facilities for member{membershipNum} = R{amountPayable}";
                        }

                        else if (rad1Hour.Checked)
                        {
                            rateAmount = weekHigherRate * 11.00;
                            amountPayable = (11.00 + rateAmount) * 1;  //1hour
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad90Min.Checked)
                        {
                            semi_amount = 11.00 + 5.5;
                            rateAmount = weekHigherRate * semi_amount;

                            amountPayable = (semi_amount + rateAmount);       //90 minutes
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad2Hours.Checked)
                        {
                            halfHour = 11.00 / 2;
                            semi_amount = 11.00 * 2;
                            withOutRate = semi_amount + halfHour;
                            weekRateAmount = 0.1 * withOutRate;
                            amountPayable = weekRateAmount + withOutRate;
                            //2hours
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }
                    }


                    if (radSquash.Checked)                      //SQUASH COURT
                    {
                        if (rad30Min.Checked)
                        {

                            halfHour = 13.00 * 0.5;
                            rateAmount = weekHigherRate * halfHour;

                            amountPayable = (halfHour + rateAmount); //30 minutes
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad1Hour.Checked)
                        {
                            rateAmount = weekHigherRate * 13.00;
                            amountPayable = (13.00 + rateAmount);//1hour
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad90Min.Checked)
                        {
                            semi_amount = 13.00 + 5.5;
                            rateAmount = weekHigherRate * semi_amount;

                            amountPayable = (semi_amount + rateAmount);        //90 minutes
                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }

                        else if (rad2Hours.Checked)
                        {
                            halfHour = 13.00 / 2;
                            semi_amount = 13.00 * 2;
                            withOutRate = semi_amount + halfHour;
                            weekRateAmount = weekHigherRate * withOutRate;
                            amountPayable = weekRateAmount + withOutRate;

                            label4.Text = $"The amount due for the facilities for member {membershipNum} = R{amountPayable}";
                        }
                    }

                }


            }










            if (txtMemberNumber.Text == "")
            {
                label4.Text = "";
                MessageBox.Show("You must enter your membership number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        
    }

        private void btnClear_Click(object sender, EventArgs e)
        {
            checkBox1.Checked = false;

            radWeights.Checked = false;
            radSwimming.Checked = false;
            radStudent.Checked = false;
            radStaff.Checked = false;
            radSquash. Checked= false;
            radPublic.Checked = false;
            radGymnasium.Checked = false;

            rad90Min.Checked = false;
            rad30Min.Checked = false;
            rad2Hours.Checked = false;
            rad1Hour.Checked = false;

            txtMemberNumber.Text = "";
            label4.Text = "";
            btnClear.Focus();
        }

        private void txtMemberNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
