﻿namespace Assignment_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rad2Hours = new System.Windows.Forms.RadioButton();
            this.rad90Min = new System.Windows.Forms.RadioButton();
            this.rad1Hour = new System.Windows.Forms.RadioButton();
            this.rad30Min = new System.Windows.Forms.RadioButton();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radWeights = new System.Windows.Forms.RadioButton();
            this.radGymnasium = new System.Windows.Forms.RadioButton();
            this.radSwimming = new System.Windows.Forms.RadioButton();
            this.radSquash = new System.Windows.Forms.RadioButton();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radPublic = new System.Windows.Forms.RadioButton();
            this.radStaff = new System.Windows.Forms.RadioButton();
            this.radStudent = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMemberNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(818, 315);
            this.btnCalculate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(138, 28);
            this.btnCalculate.TabIndex = 0;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rad2Hours);
            this.groupBox1.Controls.Add(this.rad90Min);
            this.groupBox1.Controls.Add(this.rad1Hour);
            this.groupBox1.Controls.Add(this.rad30Min);
            this.groupBox1.Font = new System.Drawing.Font("Script MT Bold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(493, 161);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(142, 224);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Duration";
            // 
            // rad2Hours
            // 
            this.rad2Hours.AutoSize = true;
            this.rad2Hours.Location = new System.Drawing.Point(22, 108);
            this.rad2Hours.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rad2Hours.Name = "rad2Hours";
            this.rad2Hours.Size = new System.Drawing.Size(87, 24);
            this.rad2Hours.TabIndex = 5;
            this.rad2Hours.TabStop = true;
            this.rad2Hours.Text = "2 Hours";
            this.rad2Hours.UseVisualStyleBackColor = true;
            // 
            // rad90Min
            // 
            this.rad90Min.AutoSize = true;
            this.rad90Min.Location = new System.Drawing.Point(22, 139);
            this.rad90Min.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rad90Min.Name = "rad90Min";
            this.rad90Min.Size = new System.Drawing.Size(76, 24);
            this.rad90Min.TabIndex = 4;
            this.rad90Min.TabStop = true;
            this.rad90Min.Text = "90 min";
            this.rad90Min.UseVisualStyleBackColor = true;
            // 
            // rad1Hour
            // 
            this.rad1Hour.AutoSize = true;
            this.rad1Hour.Location = new System.Drawing.Point(22, 75);
            this.rad1Hour.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rad1Hour.Name = "rad1Hour";
            this.rad1Hour.Size = new System.Drawing.Size(78, 24);
            this.rad1Hour.TabIndex = 3;
            this.rad1Hour.TabStop = true;
            this.rad1Hour.Text = "1 Hour";
            this.rad1Hour.UseVisualStyleBackColor = true;
            // 
            // rad30Min
            // 
            this.rad30Min.AutoSize = true;
            this.rad30Min.Location = new System.Drawing.Point(23, 39);
            this.rad30Min.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rad30Min.Name = "rad30Min";
            this.rad30Min.Size = new System.Drawing.Size(81, 24);
            this.rad30Min.TabIndex = 2;
            this.rad30Min.TabStop = true;
            this.rad30Min.Text = "30 Min";
            this.rad30Min.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(790, 288);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(90, 24);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "Weekend";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radWeights);
            this.groupBox2.Controls.Add(this.radGymnasium);
            this.groupBox2.Controls.Add(this.radSwimming);
            this.groupBox2.Controls.Add(this.radSquash);
            this.groupBox2.Font = new System.Drawing.Font("Script MT Bold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(132, 152);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(160, 224);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Facility";
            // 
            // radWeights
            // 
            this.radWeights.AutoSize = true;
            this.radWeights.Location = new System.Drawing.Point(8, 184);
            this.radWeights.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radWeights.Name = "radWeights";
            this.radWeights.Size = new System.Drawing.Size(84, 24);
            this.radWeights.TabIndex = 9;
            this.radWeights.TabStop = true;
            this.radWeights.Text = "Weights";
            this.radWeights.UseVisualStyleBackColor = true;
            // 
            // radGymnasium
            // 
            this.radGymnasium.AutoSize = true;
            this.radGymnasium.Location = new System.Drawing.Point(8, 129);
            this.radGymnasium.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radGymnasium.Name = "radGymnasium";
            this.radGymnasium.Size = new System.Drawing.Size(111, 24);
            this.radGymnasium.TabIndex = 9;
            this.radGymnasium.TabStop = true;
            this.radGymnasium.Text = "Gymnasium";
            this.radGymnasium.UseVisualStyleBackColor = true;
            // 
            // radSwimming
            // 
            this.radSwimming.AutoSize = true;
            this.radSwimming.Location = new System.Drawing.Point(8, 84);
            this.radSwimming.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radSwimming.Name = "radSwimming";
            this.radSwimming.Size = new System.Drawing.Size(135, 24);
            this.radSwimming.TabIndex = 9;
            this.radSwimming.TabStop = true;
            this.radSwimming.Text = "Swimming Pool";
            this.radSwimming.UseVisualStyleBackColor = true;
            // 
            // radSquash
            // 
            this.radSquash.AutoSize = true;
            this.radSquash.Location = new System.Drawing.Point(8, 39);
            this.radSquash.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radSquash.Name = "radSquash";
            this.radSquash.Size = new System.Drawing.Size(123, 24);
            this.radSquash.TabIndex = 9;
            this.radSquash.TabStop = true;
            this.radSquash.Text = "Squash Court";
            this.radSquash.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(818, 349);
            this.btnClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(138, 28);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radPublic);
            this.groupBox3.Controls.Add(this.radStaff);
            this.groupBox3.Controls.Add(this.radStudent);
            this.groupBox3.Font = new System.Drawing.Font("Script MT Bold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(782, 139);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(222, 145);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Membership Type";
            // 
            // radPublic
            // 
            this.radPublic.AutoSize = true;
            this.radPublic.Location = new System.Drawing.Point(8, 118);
            this.radPublic.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radPublic.Name = "radPublic";
            this.radPublic.Size = new System.Drawing.Size(73, 24);
            this.radPublic.TabIndex = 9;
            this.radPublic.TabStop = true;
            this.radPublic.Text = "Public";
            this.radPublic.UseVisualStyleBackColor = true;
            // 
            // radStaff
            // 
            this.radStaff.AutoSize = true;
            this.radStaff.Location = new System.Drawing.Point(8, 66);
            this.radStaff.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radStaff.Name = "radStaff";
            this.radStaff.Size = new System.Drawing.Size(68, 24);
            this.radStaff.TabIndex = 9;
            this.radStaff.TabStop = true;
            this.radStaff.Text = "Staff";
            this.radStaff.UseVisualStyleBackColor = true;
            // 
            // radStudent
            // 
            this.radStudent.AutoSize = true;
            this.radStudent.Location = new System.Drawing.Point(8, 22);
            this.radStudent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radStudent.Name = "radStudent";
            this.radStudent.Size = new System.Drawing.Size(82, 24);
            this.radStudent.TabIndex = 9;
            this.radStudent.TabStop = true;
            this.radStudent.Text = "Student";
            this.radStudent.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Script MT Bold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(157, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Membership Number";
            // 
            // txtMemberNumber
            // 
            this.txtMemberNumber.Font = new System.Drawing.Font("Script MT Bold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMemberNumber.Location = new System.Drawing.Point(452, 131);
            this.txtMemberNumber.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMemberNumber.Name = "txtMemberNumber";
            this.txtMemberNumber.Size = new System.Drawing.Size(182, 28);
            this.txtMemberNumber.TabIndex = 8;
            this.txtMemberNumber.TextChanged += new System.EventHandler(this.txtMemberNumber_TextChanged);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(32, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(990, 120);
            this.label2.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(83, 391);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(872, 128);
            this.label4.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("MV Boli", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(353, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(417, 38);
            this.label3.TabIndex = 11;
            this.label3.Text = "Fitness Centre - Booking";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Assignment_4.Properties.Resources._3404134;
            this.pictureBox1.Location = new System.Drawing.Point(160, 27);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(145, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1038, 531);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMemberNumber);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCalculate);
            this.Font = new System.Drawing.Font("Script MT Bold", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Assignment 6";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rad2Hours;
        private System.Windows.Forms.RadioButton rad90Min;
        private System.Windows.Forms.RadioButton rad1Hour;
        private System.Windows.Forms.RadioButton rad30Min;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radWeights;
        private System.Windows.Forms.RadioButton radGymnasium;
        private System.Windows.Forms.RadioButton radSwimming;
        private System.Windows.Forms.RadioButton radSquash;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radPublic;
        private System.Windows.Forms.RadioButton radStaff;
        private System.Windows.Forms.RadioButton radStudent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMemberNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

