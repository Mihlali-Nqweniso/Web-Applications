﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    internal class Customer
    {
        private string name;
        private int identity, birthYear;
        private string status;



        public Customer()
        {

        }
        public Customer(string aName, string aStatus, int aBirthYear, int aIdentity)
        {
            this.name = aName;
            this.identity = aIdentity;
            this.status = aStatus;
            this.birthYear = aBirthYear;
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Identity
        {
            get { return identity; }
            set { identity = value; }
        }
         public string Status
        {
            get { return status; }
            set { status = value; }
        }
        public int BirthYear
        {
            get { return birthYear; }
            set { birthYear = value; }
        }

        public void toString()
        {
            Console.WriteLine(name + " was born " + birthYear + " and her status express that she is" + status + " identity" + identity);

            Console.ReadKey();
           
        }
    }
}
