﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer1 = new Customer("Mihlali Matomane","Single",2002,020122);
          
            customer1.toString();
            Console.ReadKey();


        }
    }
}
