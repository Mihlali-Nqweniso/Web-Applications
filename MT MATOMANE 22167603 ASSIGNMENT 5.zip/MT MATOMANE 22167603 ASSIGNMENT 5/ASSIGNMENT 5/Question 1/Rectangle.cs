﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1
{
    internal class Rectangle
    {
        private double length;
        private double breadth;
        public double oneMember;
        public Rectangle()
        {
            length = 35;
            breadth = 25;
        }

        //public double Length
        //{
        //    get { return length; }
        //    set { length = value; }
        //}

        //public double Breadth
        //{
        //    get { return breadth; }
        //    set { breadth = value; }
        //}
        public double Length
        {

            get { return length * breadth; }

        }
    }
}
