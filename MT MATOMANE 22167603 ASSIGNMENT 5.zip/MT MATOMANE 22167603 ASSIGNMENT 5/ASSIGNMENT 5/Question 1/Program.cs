﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectangle rectangle1 = new Rectangle();

            //   rectangle1.oneMember =( rectangle1.Length * 2) + ( rectangle1.Breadth * 2);


            Console.WriteLine(rectangle1.Length);
            Console.ReadKey();
        }
    }
}
