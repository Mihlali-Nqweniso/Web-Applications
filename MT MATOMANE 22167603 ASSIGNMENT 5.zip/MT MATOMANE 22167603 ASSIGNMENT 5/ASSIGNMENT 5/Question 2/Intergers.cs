﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    internal class Intergers
    {
        public int num1;
        public int num2;
        public int sum;

        public Intergers() //default construtor
        {
            num1 = 24;
            num2 = 25;
            sum = 0;
        }

            


  
    }
}
