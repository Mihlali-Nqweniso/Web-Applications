﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Intergers inter1 = new Intergers();

            inter1.sum = inter1.num1 + inter1.num2;
            Console.WriteLine(inter1.sum);
            Console.ReadKey();
        }
    }
}
