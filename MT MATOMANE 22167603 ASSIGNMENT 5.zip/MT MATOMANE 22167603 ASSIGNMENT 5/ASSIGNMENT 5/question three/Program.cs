﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_three
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Thando",20);
           
            person1.toString();
            Console.ReadKey();
        }
    }
}
