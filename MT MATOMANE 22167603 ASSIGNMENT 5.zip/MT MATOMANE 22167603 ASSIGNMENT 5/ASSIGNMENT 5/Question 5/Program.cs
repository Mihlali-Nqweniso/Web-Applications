﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cum_Laude Laude = new Cum_Laude("Asanda ", "Chonco", 22167603, 75, 4.0);

            Console.WriteLine("Enter total credit of all modules of this semester for ICT(APDJ,APPDEV102,MWMU)");
            Laude.CreditS = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter total gradepoints ");
            Laude.GradePoints = Convert.ToInt32(Console.ReadLine());

            Laude.GPA = Laude.GradePoints / Laude.CreditS;

            Laude.average = (int)( Laude.GPA / Laude.gpaScale * 100);

         
                if (Laude.average>Laude.percNeeded)
                {
                    Console.WriteLine(Laude.name + Laude.surname + "" + " his student is" + Laude.studentNo + ",his average for Cum laude is" + Laude.average);

                    Console.WriteLine("Congratulations you have graduated with Cum Laude");
                }
                else
                {
                    Console.WriteLine(Laude.name + Laude.surname + "" + " his student is" + Laude.studentNo + ",his average for Cum laude is" + Laude.average);

                    Console.WriteLine("Congratulations you have graduated");
                }
           
        
           
            Console.ReadKey();
        }
    }
}
