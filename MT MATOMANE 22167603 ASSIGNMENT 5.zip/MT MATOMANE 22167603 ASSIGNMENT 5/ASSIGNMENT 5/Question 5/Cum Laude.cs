﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_5
{
    internal class Cum_Laude
    {
        public string name;
        public string surname;
        public int studentNo,percNeeded, markObtain,average;
        public double GradePoints, CreditS, GPA;
        public double gpaScale;
        public Cum_Laude()
        {
           
        }
        public Cum_Laude(string aName, string aSurname, int aStudentNo,int aPercNeeded,double aGpaScale)
        {
            this.name = aName;
            this.surname = aSurname;
            this.studentNo = aStudentNo;
            this.percNeeded= aPercNeeded;

            this.gpaScale =aGpaScale;
           
        }


    }
}
