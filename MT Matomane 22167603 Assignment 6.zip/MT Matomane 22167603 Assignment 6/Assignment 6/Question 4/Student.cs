﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    internal class Student: Person
    {
        public string subject;
        public int marks;
        public int totalMarks = 50;
        public int percNeeded;
        public int percent;
       public int dateBirth = 9;
        public string Name = "Angel";

        
       
        public void toString()
        {
            //Console.WriteLine("Enter your marks");
            //marks = Convert.ToInt32(Console.ReadLine());

            //percent = marks / totalMarks * 100;

            if (percent > percNeeded)
            {
                Console.WriteLine(Name + "your date of birth is" + dateBirth + "and you passed");
            }
            else
            {
                Console.WriteLine(Name + "your date of birth is" + dateBirth + "and you Failed");
            }

           
            }
        }
}
