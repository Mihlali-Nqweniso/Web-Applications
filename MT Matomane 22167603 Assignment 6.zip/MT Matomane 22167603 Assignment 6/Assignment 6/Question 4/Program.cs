﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    internal class Program
    {
        static void Main(string[] args)

            
        {
            Person person1 = new Person();
            person1.Name = "ThandoLwami";
            person1.dateBirth = 7;
            person1.toString();

            Student student1 = new Student();
            Console.WriteLine("Enter your marks");
            student1.marks = Convert.ToInt32(Console.ReadLine());

            student1.percent = student1.marks / student1.totalMarks * 100;
            Console.WriteLine(student1.percent);
            student1.toString();
         


            Instructor instructor1=new Instructor();
            instructor1.salary = 10000.00;
            instructor1.Name = "Mihlali";
            instructor1.dateBirth = 21;
            instructor1.netSalary = (double)(instructor1.grossSalary / 100 * instructor1.salary);
            Console.WriteLine(instructor1.netSalary);
            instructor1.toString();
            //netSalary = grossSalary / 100 * instrutor1.salary;
            Console.ReadKey();

        }
    }
}
