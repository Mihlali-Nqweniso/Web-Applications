﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    internal class Person 
    {
        public string Name;
        public int dateBirth;

        public  void toString()
        {
            Console.WriteLine("your name is"+ Name + " and you were born in " + dateBirth);

        }

    
    }

 }

