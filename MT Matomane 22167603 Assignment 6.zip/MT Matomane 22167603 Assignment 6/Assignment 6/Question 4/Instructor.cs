﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    internal class Instructor:Person
    {
       public int grossSalary= 4;
        public double salary;
        public double netSalary;
      
       

        public void toString()
        {
            //netSalary = (double) (grossSalary / 100 * salary);

            Console.WriteLine("The instruto's Name is"+ " "+ Name +" date of birth" + " "+ dateBirth + "and the net salary deducted from pension fund is "+" "+ netSalary);
        }
    }
}
