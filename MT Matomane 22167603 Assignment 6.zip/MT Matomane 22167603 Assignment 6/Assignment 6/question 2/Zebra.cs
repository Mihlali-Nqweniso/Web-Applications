﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_2
{
    internal class Zebra: Animal
    {

        public string name = "Zee";
        public int age = 12;




    }
}
