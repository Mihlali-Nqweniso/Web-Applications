﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace question_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Zebra zebra = new Zebra();
            Console.WriteLine("The ZEBRA name is " + zebra.name +" " +" and the zebra is at the age of " + zebra.age);
            Dolphin dolphin1 = new Dolphin();
            Console.WriteLine("The dolphin name is " + dolphin1.name + "" + " and the dolphin is at the age of " + dolphin1.age);
            Console.ReadKey();

            // Zebra zebra1 = new Zebra();
            // zebra1.name= "JAN";
            // zebra1.age = 12;
            //// zebra1.zebraMessage();
            // Console.ReadKey();


            //// dolphin1.dolphinMessage();
            //Console.ReadKey();


        }
    }
}
