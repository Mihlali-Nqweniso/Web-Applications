﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_2
{
    internal class Dolphin: Animal
    {

        public string name = "Dolly";
           public int age = 9;
       
    }
}
