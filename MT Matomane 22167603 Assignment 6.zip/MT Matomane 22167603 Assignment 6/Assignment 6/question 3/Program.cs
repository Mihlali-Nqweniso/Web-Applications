﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Triangle triangle1 = new Triangle();
            triangle1.ShapeArea();
         

            Rectangle rectangle1 = new Rectangle();
            rectangle1.area();
            Console.ReadKey();
        }
    }
}
