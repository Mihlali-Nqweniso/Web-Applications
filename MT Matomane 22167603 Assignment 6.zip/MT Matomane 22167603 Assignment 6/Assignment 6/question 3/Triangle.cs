﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_3
{
    internal class Triangle
    {
        public double hieght;
        public double width;
       
        public Triangle()
        {
            hieght =10.10;
           width = 7.5;

        }

        public void ShapeArea()
        {
          double area =hieght * width;
            Console.WriteLine(area);
        }
    }
}
