﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_3
{
    internal class Rectangle: Triangle
    {

        public Rectangle()
        {
            hieght = 15;
            width = 8.0;

        }
        public void area()
        {
            int area =(int) (hieght * width);
            Console.WriteLine(area);
        }
    }
}
