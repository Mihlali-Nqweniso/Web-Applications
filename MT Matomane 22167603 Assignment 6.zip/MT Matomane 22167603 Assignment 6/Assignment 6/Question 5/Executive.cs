﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_5
{
    internal class Executive:Manager
    {
        public double salary;
        

        public void toString()
        {
            Console.WriteLine("As a manager,in your own opinion was employes satisfied about their salary?");
            salary=Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("as an emplyees,are you satisfied for what you conducting?");
            salary=Convert.ToDouble((double)salary);

            Console.WriteLine("was all executive manager elated for salary they received in past few days?");
            salary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("was all information needed to provided from methos went well?");
            

        }



    }
}
