﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_5
{
    internal class Employee
    {
        public string name;
        public string surname;

        public string staffID;
        public virtual void staffNumber()
        {
            staffID = "SD000 "; /* +name + surname + ":IT";*/
        }
            public void toString()
            {
                Console.WriteLine("your name is" + "" + name + " " + "and your surname is" + "" + surname + " " + staffID);
            }

        }
    } 
