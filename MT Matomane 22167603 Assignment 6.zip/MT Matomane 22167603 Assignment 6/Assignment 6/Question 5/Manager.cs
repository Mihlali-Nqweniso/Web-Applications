﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_5
{
    internal class Manager:Employee
    {
        public string department;
            
        public  void staffNumber(string  department)
        {
            
        }
        public void toString()
        {
            string department = "SDOOF";
            Console.WriteLine(" your name is" + "" + name +" "+"and your surname is" +"" +surname + " "+"from department of" +""+ department);
        }
    }
}
