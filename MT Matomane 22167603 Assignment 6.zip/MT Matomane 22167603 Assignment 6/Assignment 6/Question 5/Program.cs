﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee employee1 = new Employee();
            employee1.name = "Thandolwami";
            employee1.surname = "Majozi";
            employee1.staffID = "SD000";
            employee1.toString();

            Manager department1 = new Manager();
            department1.name = "Mihlali";
            department1.surname = "Matomane";
            department1.staffNumber("SD00F");
            department1.toString();

            Executive executive1 = new Executive();
            executive1.toString();
            Console.ReadKey();
        }
    }
}
