﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Question_6
{
    internal class Circle:Shape
    {
        public double diameter;
        public int radius;
        public double area;
        public void Area()
        {
             area = radius * 2* 3.141;
            Console.WriteLine("AREA OF CIRCLE IS"+""+area);
        }
        public void Circum()
        {
          area = 3.141 * 14;
            Console.WriteLine("CIRCUMFERENCE OF CIRCLE IS"+""+area);
        }
    }
}
