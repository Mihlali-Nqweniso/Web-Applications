﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_6
{
    internal class Shape
    {
        public string name;

        public virtual void toString()
        {
            Console.WriteLine(name);
        }
    }
}
