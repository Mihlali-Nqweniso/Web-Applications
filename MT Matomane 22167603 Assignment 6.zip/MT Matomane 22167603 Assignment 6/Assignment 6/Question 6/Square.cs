﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_6
{
    internal class Square:Shape
    {
        public int side;

       
       // public int totalArea;
        public void Area()
        {
           int  area = side * side;
            Console.WriteLine("THE TOTAL AREA OF SQUARE IS"+" "+ area);
        }

        public void Perimeter()
        {
           int totalArea = side * 4;
            Console.WriteLine("THE PERIMETER OF SQUARE IS"+ " "+ totalArea);
            
        }
    }
}
