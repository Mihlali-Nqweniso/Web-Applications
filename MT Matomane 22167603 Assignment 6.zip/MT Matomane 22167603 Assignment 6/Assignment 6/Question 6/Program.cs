﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Shape shape1 = new Shape();
            //shape1.name= "Circle";
            //shape1.name = "square";

            shape1.toString();

            Circle circle1 = new Circle();
            circle1.radius = 7;
            circle1.name = "circle";
            circle1.toString();
            circle1.Area();
            circle1.Circum();

            Square square1 = new Square();
            square1.side = 4;
            square1.name = "square";
            square1.toString();
            square1.Area();
            square1.Perimeter();

            Triangle triangle1 = new Triangle();
            
            triangle1.height= 10.12;
            triangle1.width= 5.6;
      
            triangle1.height=10.12;
            triangle1.width = 5.6;
            triangle1.name = "Triangle";
            triangle1.toString();
            triangle1.Area();
            triangle1.Perimeter();
            Console.ReadKey();

           
        }
    }
}
