﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_6
{
    internal class Triangle:Shape
    {
        public double height;
        public double width;

        
        public void Area()
        {
            double totalArea = width * height;
            Console.WriteLine("THE TOTAL AREA OF TRIANGLE IS" + " " + totalArea);
        }

        public void Perimeter()
        {
            double perimeter=width + height + width + height;
            Console.WriteLine("THE PERIMETER OF TRIANGLE"+""+perimeter);
        }
    }
}
