﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Mother mother1 = new Mother();
            mother1.name = "Asanda";
            mother1.surname = "Chonco";
            mother1.age = 42;
            mother1.display();
           

            Daughter daughter1 = new Daughter();
            daughter1.name = "Amahle";
            daughter1.surname = "Chonco";
            daughter1.age = 18;
            daughter1.display();
            Console.ReadKey();
        }
    }
}
