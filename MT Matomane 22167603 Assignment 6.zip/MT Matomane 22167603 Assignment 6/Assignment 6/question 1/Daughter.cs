﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_1
{
    internal class Daughter :Mother
    {
        public override void display()
        {
            Console.WriteLine(name + " your mother HAS BEEN found");
           
        }
    }
}
