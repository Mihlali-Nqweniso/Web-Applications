﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_1
{
    internal class Mother
    {
        public string name;
        public string surname;
        public int age;

        public virtual void display() 
        {
            Console.WriteLine(name +" you are a mother of a daughter");
           
        }
    }
}
