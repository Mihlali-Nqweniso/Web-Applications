﻿namespace Practical_assignment2_Section_A
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtNumOfStudents = new TextBox();
            txtNumOfPages = new TextBox();
            txtNumOfPapers = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            lblDisplay = new Label();
            btnCalc = new Button();
            btnClear = new Button();
            btnExit = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtNumOfStudents);
            groupBox1.Controls.Add(txtNumOfPages);
            groupBox1.Controls.Add(txtNumOfPapers);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(32, 33);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(612, 237);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Provide the following values";
            // 
            // txtNumOfStudents
            // 
            txtNumOfStudents.Location = new Point(332, 174);
            txtNumOfStudents.Name = "txtNumOfStudents";
            txtNumOfStudents.Size = new Size(173, 27);
            txtNumOfStudents.TabIndex = 5;
            // 
            // txtNumOfPages
            // 
            txtNumOfPages.Location = new Point(332, 113);
            txtNumOfPages.Name = "txtNumOfPages";
            txtNumOfPages.Size = new Size(173, 27);
            txtNumOfPages.TabIndex = 4;
            // 
            // txtNumOfPapers
            // 
            txtNumOfPapers.Location = new Point(332, 53);
            txtNumOfPapers.Name = "txtNumOfPapers";
            txtNumOfPapers.Size = new Size(173, 27);
            txtNumOfPapers.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 181);
            label3.Name = "label3";
            label3.Size = new Size(204, 20);
            label3.TabIndex = 2;
            label3.Text = "Number of first year students:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 116);
            label2.Name = "label2";
            label2.Size = new Size(223, 20);
            label2.TabIndex = 1;
            label2.Text = "Number of pages in assignment:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 53);
            label1.Name = "label1";
            label1.Size = new Size(189, 20);
            label1.TabIndex = 0;
            label1.Text = "Number of reams of paper:";
            // 
            // lblDisplay
            // 
            lblDisplay.BorderStyle = BorderStyle.FixedSingle;
            lblDisplay.Location = new Point(32, 283);
            lblDisplay.Name = "lblDisplay";
            lblDisplay.Size = new Size(612, 164);
            lblDisplay.TabIndex = 1;
            // 
            // btnCalc
            // 
            btnCalc.Location = new Point(32, 461);
            btnCalc.Name = "btnCalc";
            btnCalc.Size = new Size(94, 29);
            btnCalc.TabIndex = 2;
            btnCalc.Text = "Calculate";
            btnCalc.UseVisualStyleBackColor = true;
            btnCalc.Click += btnCalc_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(285, 461);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 29);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(550, 461);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(94, 29);
            btnExit.TabIndex = 4;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 515);
            Controls.Add(btnExit);
            Controls.Add(btnClear);
            Controls.Add(btnCalc);
            Controls.Add(lblDisplay);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Practical Assignment 2";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtNumOfStudents;
        private TextBox txtNumOfPages;
        private TextBox txtNumOfPapers;
        private Label lblDisplay;
        private Button btnCalc;
        private Button btnClear;
        private Button btnExit;
    }
}
