namespace Practical_assignment2_Section_A
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {

            int numberOfReams = Convert.ToInt32(txtNumOfPapers.Text);
            int numberOfPages = Convert.ToInt32(txtNumOfPages.Text);
            int numberOfStudents = Convert.ToInt32(txtNumOfStudents.Text);

            int totalPagesRequired = numberOfStudents * numberOfPages;
            int totalPagesAvailable = numberOfReams * 500;

            if (totalPagesAvailable >= totalPagesRequired)
            {
                int pagesLeft = totalPagesAvailable - totalPagesRequired;
                lblDisplay.Text = $"The paper is sufficient. You will have {pagesLeft} pages left.";
            }
            else
            {
                int pagesShort = totalPagesRequired - totalPagesAvailable;
                lblDisplay.Text = $"The paper is not sufficient. You will be short of {pagesShort} pages.";

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNumOfPapers.Text = "";
            txtNumOfPages.Text = "";
            txtNumOfStudents.Text = "";


            lblDisplay.Text = "";

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}