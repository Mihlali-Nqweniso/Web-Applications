namespace Section_B_Practical_Assignment_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPriceOfItem.Clear();
            txtPriceOfBulk.Clear();
            txtNumOfBulkOfPackage.Clear();
            lblDisplay.Text = "";
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
        
            double priceOfItem = Convert.ToDouble(txtPriceOfItem.Text);
            double priceOfBulk = Convert.ToDouble(txtPriceOfBulk.Text);
            int numOfBulkInPackage = Convert.ToInt32(txtNumOfBulkOfPackage.Text); 

       
            double costPerItemBulk = priceOfBulk / numOfBulkInPackage; 

          
            if (priceOfItem < costPerItemBulk)
            {
                double percentageSaving = ((costPerItemBulk - priceOfItem) / costPerItemBulk) * 100;
                lblDisplay.Text = $"It is cheaper to buy the item individually.\nYou save {percentageSaving:F2}% per item.";
            }
            else if (costPerItemBulk < priceOfItem)
            {
                double percentageSaving = ((priceOfItem - costPerItemBulk) / priceOfItem) * 100;
                lblDisplay.Text = $"It is cheaper to buy in bulk.\nYou save {percentageSaving:F2}% per item.";
            }
            else
            {
                lblDisplay.Text = "The cost is the same whether you buy individually or in bulk.";
            }
        }
    }
}
