﻿namespace Section_B_Practical_Assignment_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCalc = new Button();
            btnClear = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            lblDisplay = new Label();
            btnExit = new Button();
            txtPriceOfItem = new TextBox();
            txtPriceOfBulk = new TextBox();
            txtNumOfBulkOfPackage = new TextBox();
            SuspendLayout();
            // 
            // btnCalc
            // 
            btnCalc.Location = new Point(87, 478);
            btnCalc.Name = "btnCalc";
            btnCalc.Size = new Size(108, 39);
            btnCalc.TabIndex = 0;
            btnCalc.Text = "Calculate";
            btnCalc.UseVisualStyleBackColor = true;
            btnCalc.Click += btnCalc_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(315, 478);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(125, 39);
            btnClear.TabIndex = 1;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(205, 60);
            label1.Name = "label1";
            label1.Size = new Size(273, 41);
            label1.TabIndex = 3;
            label1.Text = "GOODIES GALORE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(87, 122);
            label2.Name = "label2";
            label2.Size = new Size(194, 20);
            label2.TabIndex = 4;
            label2.Text = "Enter the price for one item:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(87, 191);
            label3.Name = "label3";
            label3.Size = new Size(235, 20);
            label3.TabIndex = 5;
            label3.Text = "Enter the price for a bulk package:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(87, 259);
            label4.Name = "label4";
            label4.Size = new Size(317, 20);
            label4.TabIndex = 6;
            label4.Text = "Enter the number of items in the bulk package:";
            // 
            // lblDisplay
            // 
            lblDisplay.BorderStyle = BorderStyle.FixedSingle;
            lblDisplay.Location = new Point(87, 327);
            lblDisplay.Name = "lblDisplay";
            lblDisplay.Size = new Size(648, 122);
            lblDisplay.TabIndex = 7;
            lblDisplay.Click += label5_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(641, 478);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(94, 39);
            btnExit.TabIndex = 2;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // txtPriceOfItem
            // 
            txtPriceOfItem.Location = new Point(565, 122);
            txtPriceOfItem.Name = "txtPriceOfItem";
            txtPriceOfItem.Size = new Size(170, 27);
            txtPriceOfItem.TabIndex = 8;
            txtPriceOfItem.TextChanged += textBox1_TextChanged;
            // 
            // txtPriceOfBulk
            // 
            txtPriceOfBulk.Location = new Point(565, 184);
            txtPriceOfBulk.Name = "txtPriceOfBulk";
            txtPriceOfBulk.Size = new Size(170, 27);
            txtPriceOfBulk.TabIndex = 9;
            // 
            // txtNumOfBulkOfPackage
            // 
            txtNumOfBulkOfPackage.Location = new Point(577, 252);
            txtNumOfBulkOfPackage.Name = "txtNumOfBulkOfPackage";
            txtNumOfBulkOfPackage.Size = new Size(158, 27);
            txtNumOfBulkOfPackage.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(961, 540);
            Controls.Add(txtNumOfBulkOfPackage);
            Controls.Add(txtPriceOfBulk);
            Controls.Add(txtPriceOfItem);
            Controls.Add(lblDisplay);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnExit);
            Controls.Add(btnClear);
            Controls.Add(btnCalc);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCalc;
        private Button btnClear;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label lblDisplay;
        private Button btnExit;
        private TextBox txtPriceOfItem;
        private TextBox txtPriceOfBulk;
        private TextBox txtNumOfBulkOfPackage;
    }
}
